package com.example.drawinggame;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class DrawingActivity extends AppCompatActivity {

    private DrawingView drawingView;
    private String chosenWord;
    private int guessCount = 0;
    private int remainingGuesses = 3; // Start with 3 guesses
    private boolean isDrawing = true;  // To track whether it's Player 1's drawing phase or Player 2's guessing phase

    private TextView tvRemainingGuesses; // TextView for remaining guesses

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drawing);

        // Retrieve the word selected by Player 1
        chosenWord = getIntent().getStringExtra("CHOSEN_WORD");

        // Bind views
        drawingView = findViewById(R.id.drawing_view);
        Button btnDone = findViewById(R.id.btn_done);
        Button btnEraser = findViewById(R.id.btn_eraser);
        Button btnClearCanvas = findViewById(R.id.btn_clear_canvas);
        tvRemainingGuesses = findViewById(R.id.tv_remaining_guesses); // Initialize the remaining guesses TextView
        TextView tvGuessPrompt = findViewById(R.id.tv_guess_prompt);
        EditText etGuess = findViewById(R.id.et_guess);
        Button btnSubmitGuess = findViewById(R.id.btn_submit_guess);

        // Color selection squares
        findViewById(R.id.color_red).setOnClickListener(v -> drawingView.setPenColor(Color.RED));
        findViewById(R.id.color_orange).setOnClickListener(v -> drawingView.setPenColor(Color.parseColor("#FFA500"))); // Orange
        findViewById(R.id.color_yellow).setOnClickListener(v -> drawingView.setPenColor(Color.YELLOW));
        findViewById(R.id.color_green).setOnClickListener(v -> drawingView.setPenColor(Color.GREEN));
        findViewById(R.id.color_blue).setOnClickListener(v -> drawingView.setPenColor(Color.BLUE));
        findViewById(R.id.color_indigo).setOnClickListener(v -> drawingView.setPenColor(Color.parseColor("#4B0082"))); // Indigo
        findViewById(R.id.color_black).setOnClickListener(v -> drawingView.setPenColor(Color.BLACK));

        // Done button
        btnDone.setOnClickListener(v -> {
            drawingView.setEnabled(false);  // Disable drawing after done
            btnDone.setVisibility(View.GONE);

            // Switch to guessing mode (Player 2's turn)
            isDrawing = false;
            tvGuessPrompt.setVisibility(View.VISIBLE);
            etGuess.setVisibility(View.VISIBLE);
            btnSubmitGuess.setVisibility(View.VISIBLE);
            tvRemainingGuesses.setVisibility(View.VISIBLE);
        });

        // Eraser button
        btnEraser.setOnClickListener(v -> {
            if (isDrawing) {
                drawingView.setToEraserMode();
            }
        });

        // Clear canvas button
        btnClearCanvas.setOnClickListener(v -> {
            if (isDrawing) {
                drawingView.clearCanvas();
            }
        });

        // Submit guess button
        btnSubmitGuess.setOnClickListener(v -> {
            String guess = etGuess.getText().toString().trim();
            guessCount++;

            // Decrease remaining guesses and update the TextView
            remainingGuesses--;
            tvRemainingGuesses.setText("Guesses remaining: " + remainingGuesses);

            if (guess.equalsIgnoreCase(chosenWord)) {
                // Correct guess - navigate to the result screen
                Toast.makeText(this, "Correct!", Toast.LENGTH_SHORT).show();
                navigateToGameResult(true);
            } else if (remainingGuesses <= 0) {
                // Out of guesses - navigate to the result screen with the correct word
                Toast.makeText(this, "Out of guesses! The word was " + chosenWord, Toast.LENGTH_SHORT).show();
                navigateToGameResult(false);
            } else {
                Toast.makeText(this, "Try again!", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void navigateToGameResult(boolean isCorrect) {
        // Navigate to GameResultActivity with a message about the result
        Intent intent = new Intent(DrawingActivity.this, GameResultActivity.class);
        if (isCorrect) {
            intent.putExtra("RESULT_MESSAGE", "You guessed correctly!");
        } else {
            intent.putExtra("RESULT_MESSAGE", "Out of guesses! The word was " + chosenWord);
        }
        startActivity(intent);
        finish();
    }
}
