package com.example.drawinggame;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class GameResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_game_result);

        // Get references to UI elements
        TextView resultMessage = findViewById(R.id.tv_result_message);
        Button playAgainButton = findViewById(R.id.btn_play_again);
        Button homePageButton = findViewById(R.id.btn_home_page);

        // Get the result message passed from the previous activity
        String result = getIntent().getStringExtra("RESULT_MESSAGE");
        if (result != null) {
            resultMessage.setText(result);
        }

        // Set up the "Play Again" button
        playAgainButton.setOnClickListener(v -> {
            Intent intent = new Intent(GameResultActivity.this, WordSelectionActivity.class);
            startActivity(intent);
            finish();
        });

        // Set up the "Home Page" button
        homePageButton.setOnClickListener(v -> {
            //Intent intent = new Intent(GameResultActivity.this, HomeActivity.class);
            //startActivity(intent);
            //finish();
        });
    }
}
