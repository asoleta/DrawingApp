package com.example.drawinggame;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.Arrays;
import java.util.Collections;
import java.util.List;

public class WordSelectionActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_word_selection);

        // Full list of possible words
        String[] words = {"Apple", "Dog", "House", "Tree", "Car", "Cat", "Moon", "Sun", "Ball", "Chair"};

        // Shuffle the array to randomize word selection
        List<String> wordList = Arrays.asList(words);
        Collections.shuffle(wordList);

        // Select the first three words from the shuffled list
        String[] selectedWords = wordList.subList(0, 3).toArray(new String[0]);

        // Find the buttons in the layout
        Button btnWord1 = findViewById(R.id.btn_word1);
        Button btnWord2 = findViewById(R.id.btn_word2);
        Button btnWord3 = findViewById(R.id.btn_word3);

        // Set the text of the buttons to the selected words
        btnWord1.setText(selectedWords[0]);
        btnWord2.setText(selectedWords[1]);
        btnWord3.setText(selectedWords[2]);

        // Listener to handle button clicks and pass the chosen word to the DrawingActivity
        View.OnClickListener listener = view -> {
            String chosenWord = ((Button) view).getText().toString();
            Intent intent = new Intent(this, DrawingActivity.class);
            intent.putExtra("CHOSEN_WORD", chosenWord);
            startActivity(intent);
        };

        // Set the click listener for all three buttons
        btnWord1.setOnClickListener(listener);
        btnWord2.setOnClickListener(listener);
        btnWord3.setOnClickListener(listener);
    }

}